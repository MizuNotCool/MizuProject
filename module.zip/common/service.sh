#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

# Governor
su -lp 2000 -c "cmd notification post -S bigtext -t 'SuzuOS Plugin - MizuProject' tag 'Starting daemon. Your device will get lag a little bit'"
sleep 2
echo 2048M >/sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon  /dev/block/zram0
su -lp 2000 -c "cmd notification post -S bigtext -t 'SuzuOS Plugin - MizuProject' tag 'Activated'"
su -c pm disable com.google.android.gms/.chimera.GmsIntentOperationService