#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

# Governor
sleep 2
echo 2048M >/sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon  /dev/block/zram0
su -c pm disable com.google.android.gms/.chimera.GmsIntentOperationService
su -c fstrim -v /data
su -c fstrim -v /system
su -c fstrim -v /cache
su -c fstrim -v /vendor