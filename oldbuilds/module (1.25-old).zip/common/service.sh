#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

# Governor
sleep 2
echo 2560M >/sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon  /dev/block/zram0
pm disable com.google.android.gms/.chimera.GmsIntentOperationService
busybox fstrim -v /data
busybox fstrim -v /system
busybox fstrim -v /cache
busybox fstrim -v /vendor
busybox_phh fstrim -v /data
busybox_phh fstrim -v /system
busybox_phh fstrim -v /cache
busybox_phh fstrim -v /vendor
rm -rf /data/data/*/cache/*
rm -rf /sdcard/Android/data/*/cache/*
rm -rf /data/dalvik-cache/*
rm -rf /storage/*-*/Android/data/*/cache/*
chmod 660 /sys/fs/selinux/enforce
chmod 440 /sys/fs/selinux/policy
pm bg-dexopt-job