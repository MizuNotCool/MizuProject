#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

# Governor
sleep 2
echo 2560M >/sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon  /dev/block/zram0
su -c pm disable com.google.android.gms/.chimera.GmsIntentOperationService
su -c busybox fstrim -v /data
su -c busybox fstrim -v /system
su -c busybox fstrim -v /cache
su -c busybox fstrim -v /vendor
su -c busybox_phh fstrim -v /data
su -c busybox_phh fstrim -v /system
su -c busybox_phh fstrim -v /cache
su -c busybox_phh fstrim -v /vendor
su -c rm -rf /data/data/*/cache/*
su -c rm -rf /sdcard/Android/data/*/cache/*
su -c rm -rf /data/dalvik-cache/*
su -c rm -rf /storage/*-*/Android/data/*/cache/*
su -c chmod 660 /sys/fs/selinux/enforce
su -c chmod 440 /sys/fs/selinux/policy
su -c pm bg-dexopt-job