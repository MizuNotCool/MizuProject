# !/sbin/sh

# Smiley_18 @ xda developers

busybox mount /system

#Backup

if [ ! -f /system/vendor/etc/thermal-engine.conf.parth ]; then
  cp /system/vendor/etc/thermal-engine.conf /system/vendor/etc/thermal-engine.conf.parth
fi

if [ ! -f /system/etc/thermal-engine.conf.parth ]; then
  cp /system/etc/thermal-engine.conf /system/vendor/etc/thermal-engine.conf.parth
fi

if [ ! -f /system/vendor/etc/.tp/thermal.conf.parth ]; then
  cp /system/vendor/etc/.tp/thermal-engine.conf /system/vendor/etc/thermal.conf.parth
fi

if [ ! -f /system/etc/thermal.conf.parth ]; then
  cp /system/etc/thermal.conf /system/vendor/etc/.tp/thermal-engine.conf.parth
fi
